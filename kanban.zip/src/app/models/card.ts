export class Card {
  // Classe CARD
  // tslint:disable-next-line: variable-name
  _id: string;
  nome: string;
  descricao: string;
  board: number;
  tag: string;
}
