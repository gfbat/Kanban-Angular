export class Tag {
  // Classe TAG
  // tslint:disable-next-line: variable-name
  _id: string;
  nome: string;
}
